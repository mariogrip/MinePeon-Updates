<?php
/*
 *  GHashForCash Client for minepeon
 *  Written by James Thompson - ProAidive Solutions
 *  2014 March 27th 
 */

class ghashForCashClient{
	private $minerName;
	private $serverKey;
	private $urlRoot;
	private $moduleEnabled;
	private $userEmail;
	private $appKey;
	private $minerKey;
	private $pools = array();
	private $pool0 = array();
	private $mhsav;
	private $contractstatus;
	private $minerownerpools;
	private $timezone;
	private $minepeonversion;
	private $mpCPULoad;
	
	function __construct($install=false){

		if(!$install){
			/* API Info for GHashForCashClient - ** DO NOT CHANGE ** */
			$this->minerName  = "MinePeon";
			$this->serverKey  = "lstJBFq5kWeZInmd";
			$this->urlRoot    = "http://cryptominer.mine.nu:8080/maps/api/";
	
			/* Load options from minepeon.conf */
			
			$config = json_decode(file_get_contents("/opt/minepeon/etc/minepeon.conf",false));
			
			$this->timezone = $config->userTimezone;

			date_default_timezone_set($config->userTimezone);
			
			/* check to see if GHashForCashClient module is enabled */
			if($config->ghfc_enabled === true){
				
				$this->moduleEnabled = true;
				/* check for email and appKey - exit if not found */
				if($config->ghfc_userEmail && $config->ghfc_appKey){
					$this->userEmail  = $config->ghfc_userEmail;
					$this->appKey     = $config->ghfc_appKey;
					$this->minerKey   = $config->ghfc_minerKey;
					$this->MName      = $config->ghfc_machineName;
				}
				
				$mineruserconf = json_decode(file_get_contents("/opt/minepeon/etc/miner.user.conf", true), true);
					
				$this->minerownerpools = $mineruserconf['pools'];
				
				//Get the current minepeon version
				$this->minepeonversion = exec('cat /opt/minepeon/etc/version');
				
				//MinePeon CPU load
				$mpCPULoad = sys_getloadavg();
				
			}
			
		}else{
			return;
		}

		
	}
	

	
	function processServerResponse($serverResponse){

		$directive = $serverResponse->directive;
		
		//Store the contract information from GHash4Cash
		$this->contractstatus['contractStatus'] = $serverResponse->contractstatus;
		$this->contractstatus['contractno'] =  $serverResponse->contractno;
		
		
		
		//Debug log output
		var_dump($serverResponse);
		
		if ($directive == 'RESET'){
			$this->contractstatus['contractStatus'] = "";
			$this->contractstatus['contractno'] = "";
			$this->contractstatus['poolurl'] = '';
			$this->contractstatus['workername'] = '';
			$this->contractstatus['password'] ='';
			writeSettings($this->contractstatus,"contractstatus.dat");
			//remove all non user pools
			$this->removeNonUserPools();
		
		}elseif ($directive == 'NEWPOOL'){
			//Only Called when there is a contract assignment

			sleep(2);
			$this->newPool($serverResponse->poolurl, $serverResponse->poolworkername,$serverResponse->poolpassword, $serverResponse->contractno);
			$this->contractstatus['poolurl'] = $serverResponse->poolurl;
			$this->contractstatus['workername'] = $serverResponse->poolworkername;
			$this->contractstatus['password'] = $serverResponse->poolpassword;
			writeSettings($this->contractstatus,"contractstatus.dat");
		}else{
			if ($this->contractstatus['contractStatus'] == "OFFCONTRACT"){
				$this->removeNonUserPools();
			}
		}
	}
	
	function findDonatePool($addr){
	   $donatePool = -1;
		foreach ($this->pools as $k => $v) {
			if(isset($v['User']) && $v['User']==$addr){
				$donatePool = $k;
			}
		}
		return $donatePool;
	}
	
	function newPool($poolAddress, $poolUser, $poolPass, $contractno){
		miner("addpool",$poolAddress . "," . $poolUser . "," . $poolPass);
	
		// Sleep for 5 secconds to avoid monitor scripts
		sleep(5);
	
		$pool = $this->findDonatePool($poolUser);

		$poolswitch = miner('switchpool',$pool);
	
		//send the result of the pool switch to gh4cash server
		$switchstatus = $poolswitch["STATUS"]["0"];
		$switchstatus['contractno'] = $contractno;
		$url = $this->urlRoot . "newpoolreply.php";
		$json = $this->do_post_request($url, $switchstatus);
	
	}
	
	public function reportContractStatus(){
		//Load Contract Status
		require_once '/opt/minepeon/http/inc/settings.inc.php';

		if ($this->minerKey == ''){
			die;
		}
		$this->loadContractStatus();
		
		$this->loadPoolsSortedByPriority();
		$this->loadDevices();
		
		
		$data = array();
		$contractpool = array();
		if ($this->contractstatus['contractStatus'] == 'ACTIVE'){
			$contractpool = $this->findPoolContractPool($this->contractstatus);
			if (count($contractpool) != 0){
				//Is the zero priority pool the contract pool
				if (count(array_diff($contractpool,$this->pools[0])) != 0){
					if ($contractpool['Status'] == 'Alive'){
						//switch to the contract pool
						//owner may have set priority
						
						$this->promotePool($this->contractstatus['poolurl'],$this->contractstatus['workername']);
						
						$this->loadPoolsSortedByPriority();
						
						$data['contractpoolpriority0'] = 'NO';
						$data['prioritychanged'] = 'YES';
						//Should record changeTo
						//Report switch to ghashforcash
					}else{
						//Use dead pool info as contract status send to ghash4cash
						$data['contractpooldead'] = 'YES';
					}
				}else{
					$data['contractpoolpriority0'] = 'YES';
				}
					
				//Use the contrat pool for send status
				$this->pool0 = $contractpool;
					
			}else{
				//contract pool not in the pool list .... hmmmmmmm
				//could be from owner reset or power failure
				$data['contractpoolinlist'] = 'NO';
			}
		
		}else{
		
		}
		

		$poolurl = $this->pool0['URL'];
		
		$pooluser =  $this->pool0['User'];
		
		$poolstatus =  $this->pool0['Status'];
		$lastsharetime =  date('H:i:s', $this->pool0['LastShareTime']);
		$minerdate = date('D, d M Y H:i:s T');
		
		
		
		$data['status'] = $this->contractstatus['contractStatus'];
		$data['contractno'] = $this->contractstatus['contractno'];
		$data['result'] = 'json';
		$data['mhsav'] = urlencode($this->mhsav);
		$data['poolurl'] = $poolurl;
		$data['pooluser'] = $pooluser;
		$data['poolstatus'] = $poolstatus;
		$data['lastsharetime'] = $lastsharetime;
		$data['minerdate'] = $minerdate;
		$data['paypal_email'] = $this->userEmail;
		
		if (ISSET($contractpool['Status'])){
			$data['contractpoolstatus'] = $contractpool['Status'];
		}
		
		$date['poolpriorityswitch'] = '';
		var_dump($data);
		
		
		$url = $this->urlRoot . "minerStatus.php";
		
		$json = $this->do_post_request($url, $data);
		$response = json_decode($json);
		
		
		//Handle Return Function
		if (!ISSET($response->directive)){
			die;
		}
			
		$this->processServerResponse($response);
		
		
	}
	/*
	 * Send the current miner summary and status for SubminerStat remote monitor
	 */
	public function updateSubminerStat(){
		if ($this->minerKey == ''){
			die;
		}
		
		include('miner.inc.php');
		$this->loadDevices();
		$this->loadPoolsSortedByPriority();
		
		$summary = miner("summary", "");
		
		$minepeon = array();
		$minepeon['PiTemp'] = $PiTemperature = round(exec('cat /sys/class/thermal/thermal_zone0/temp') / 1000, 2);
		$minepeon['mpCPULoad'] = $this->mpCPULoad;
		$minepeon['mpVersion'] = $this->minepeonversion;
		$minepeon['Timezone'] = $this->timezone;
		
		$minerstat = array();
		$minerstat['summary'] = $summary;
		$minerstat['pools'] = $this->pools;
		$minerstat['devs']  = $this->devs;
		
		$minerstat['minepeon'] = $minepeon;
		
		$url = $this->urlRoot . "monitor.php";
		
		$json = $this->do_post_json($url, $minerstat);
		
	}
	
	function loadDevices(){
		include_once('miner.inc.php');
		$stats = miner("devs", "");
		$this->devs = $stats['DEVS'];
		
		//Get the total GHash rate of each of the devices
		$this->mhsav = 0;
		foreach ($this->devs as $dev){
			$this->mhsav += $dev['MHSav'];
		}
	}
	function findPoolContractPool($contractstatus){
		$returnPool = array();

		foreach ($this->pools as $pool){
			if ($pool['URL'] == $this->contractstatus['poolurl'] && $pool['User'] == $this->contractstatus['workername']){
				$returnPool = $pool;
				break;
			}
			
		}

		return $returnPool;
	}
	
	
	function loadPoolsSortedByPriority(){
		include_once('miner.inc.php');
		$cgPools = miner("pools", "");
		$pools = $cgPools['POOLS'];
		$this->array_sort_by_column($pools, 'Priority');

		if (count($pools) > 0){
			$this->pool0 = $pools[0];
		}
		
		$this->pools = $pools;
	}
	function loadContractStatus(){
		$contractstatus = array();
		$contractstatusfile = "/opt/minepeon/etc/contractstatus.dat";
		if (file_exists($contractstatusfile)){
			$contractstatus = json_decode(file_get_contents($contractstatusfile, true), true);
		}else{
			//missing file
			echo 'Missing:' . $contractstatusfile;
		}
		$this->contractstatus = $contractstatus;
		var_dump($this->contractstatus);
		
		
	}
	function handleServerResponse(){
		
	}
	/*
	 * Remove GHashForCash plugin
	*/
	public function uninstall(){
	
		/* Inform GHashForCash to the miner is disabled
		 * 
		 */
		//$this->sendUninstallNotification();
		/* disable plugin in minepeon.conf */
		$file   = "/opt/minepeon/etc/minepeon.conf";
		$open   = fopen($file,'r') or die("Can not open minepeon.conf");
		$data   = fread($open,filesize($file));
		$conf   = json_decode($data,true);
		
		
		if(is_array($conf)){
			$conf['ghfc_enabled']      = false;
			$conf['ghfc_userEmail']    = "";
			$conf['ghfc_appKey']       = "";
			$conf['ghfc_minerKey']     = "";
			$conf['ghfc_appKey']       = "";
			$conf['ghfc_appKey']       = "";
			$conf['ghfc_machineName']  = "";
			
			
			
			$write = fopen($file,'w');
			fwrite($write,json_encode($conf,JSON_PRETTY_PRINT));
			fclose($write);
		}
	}
	
	/*
	 * Send uninstall notification to GHashForCash Server.
	 */
	public function sendUninstallNotification(){
		$data = array();
		$url = "http://cryptominer.mine.nu:8080/maps/api/minerdiduninstall.php";

		$data['minerKey'] = $this->minerKey;
		
		$json = $this->do_post_request($url, $data);
		$response = json_decode($json);
	}
	
	function promotePool($addr, $user){

		foreach ($this->pools as $key => $value) {
			if(isset($value['User']) && $value['URL']==$addr && $value['User']==$user){

		  	miner('switchpool',$key);
			}
			
		}
	
	}
	
	function do_post_request($url, $data, $optional_headers = null)
	{
		$data['minerKey'] = $this->minerKey;
		$data['serverKey'] = $this->serverKey;
		$data['appkey'] = $this->appKey;
		
		$data['function'] = "OyDzrR0BgwehqEJZBhxyeuw19F2s4TQy6LITHGqK";
		$params = array('http' => array(
				'method' => 'POST',
				'content' => http_build_query($data)
		));
		if ($optional_headers !== null) {
			$params['http']['header'] = $optional_headers;
		}
		$ctx = stream_context_create($params);
		$fp = @fopen($url, 'rb', false, $ctx);
		if (!$fp) {
			throw new Exception("Problem with $url, $php_errormsg");
		}
		$response = @stream_get_contents($fp);
		if ($response === false) {
			throw new Exception("Problem reading data from $url, $php_errormsg");
		}
		return $response;
	}
	
	function do_post_json($url,$data){
		echo $url . '\n';
		
		$data['function'] = "OyDzrR0BgwehqEJZBhxyeuw19F2s4TQy6LITHGqK";
		$data['appkey'] = $this->appKey;
		$data['minerKey'] = $this->minerKey;
		$data['serverKey'] = $this->serverKey;
		var_dump($data);
		$options = array(
				'http' => array(
						'method'  => 'POST',
						'content' => json_encode( $data ),
						'header'=>  "Content-Type: application/json\r\n" .
						"Accept: application/json\r\n"
				)
		);
	
		$context  = stream_context_create( $options );
		$result = file_get_contents( $url, false, $context );
	
		return json_decode( $result );
	
	}
	function removeNonUserPools(){   //Replaces Reset Miner call
		$this->switchToFirstPriorityOwnerPool();

		 
		foreach ($this->pools as $k => $v) {
			$pool_n = $k;
			$isownerpool = false;
			foreach($this->minerownerpools as $minerownerpool){
				if ($minerownerpool['user'] == $v['User'] && $minerownerpool['url'] == $v['URL']){
					$isownerpool = true;
				}
			}
			 
			if (!$isownerpool){
				$poolswitch = miner('removepool',$pool_n);
			}
	
		}
		 
		return true;
	}
	function switchToFirstPriorityOwnerPool(){
		$returnValue = -1;
		

		$pool_n = -1;
		foreach ($this->pools as $k => $v) {
			$pool_n = $k;
			foreach($this->minerownerpools as $minerownerpool){
				if ($minerownerpool['user'] == $v['User'] && $minerownerpool['url'] == $v['URL']){
					$pool_n = $k;
					echo 'User Priority Pool:' . $pool_n;
					break;
				}
			}
			if ($pool_n >=0){
				break;
			}
		}
	
		if ($pool_n >= 0){
			$poolswitch = miner('switchpool',$pool_n);
			var_dump($poolswitch);
		}
		return $pool_n;
	}
	
	function checkIndexPhpRefresh(){
		$searchthis = '<meta http-equiv="refresh" content="600">';
		$matches = array();
		
		$handle = @fopen("/opt/minepeon/http/head.php", "r");
		if ($handle)
		{
			while (!feof($handle))
			{
				$buffer = fgets($handle);
				if(strpos($buffer, $searchthis) !== FALSE)
					$matches[] = $buffer;
			}
			fclose($handle);
		}
		
		if (count($matches)>0){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	function array_sort_by_column(&$arr, $col, $dir = SORT_ASC) {
		$sort_col = array();
		foreach ($arr as $key=> $row) {
			$sort_col[$key] = $row[$col];
		}
	
		array_multisort($sort_col, $dir, $arr);
	}
	
	
	/*
	 * Install CronJobs to support /// Addon
	*/
	public function installCron(){
		return;
	}
	
	
	/*
	 * Install variable into minepeon configuration file for MMA addon to work properly.
	*/
	
	
	public function installConf($settings){

		$file   = "/opt/minepeon/etc/minepeon.conf";
		$open   = fopen($file,'r') or die("Can not open minepeon.conf");
		$data   = fread($open,filesize($file));
		$conf   = json_decode($data,true);
		if(is_array($conf)){
			$conf['ghfc_enabled'] = true;
			$conf['ghfc_userEmail'] = $settings['email'];
			$conf['ghfc_minerKey'] = $settings['minerkey'];
			$conf['ghfc_appKey']  = $settings['appkey'];
			$conf['ghfc_paypalEmail'] = $settings['paypalemail'];
			
			if(isset($settings['name'])){
				$conf['ghfc_machineName']  = $settings['name'];
			}
	
			$write = fopen($file,'w');
			fwrite($write,json_encode($conf,JSON_PRETTY_PRINT));
			fclose($write);
		}
	}
	
	
}