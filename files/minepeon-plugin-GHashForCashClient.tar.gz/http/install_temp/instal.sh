sudo mkdir /home/minepeon/hello


