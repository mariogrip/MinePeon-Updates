<?php

include('../../inc/settings.inc.php');
require_once "/opt/minepeon/http/plugins/ghfc/ghashforcashclient.inc.php";

$writeSettings=false;
$ghfc = new ghashForCashClient();

if (isset($_POST['Email'])) {
	//echo "/usr/bin/php /opt/minepeon/http/plugins/ghfc/run.php installconf '" . $_POST['Email'] . "' '" . $_POST['payPalEmail'] . "' '" .  $_POST['minerKey'] . "' '" . $_POST['AppKey'] . "' '" . $_POST['MName'] . "'";
	
	exec("/usr/bin/php /opt/minepeon/http/plugins/ghfc/run.php installconf '" . $_POST['Email'] . "' '" . $_POST['payPalEmail'] . "' '" .  $_POST['minerKey'] . "' '" . $_POST['AppKey'] . "' '" . $_POST['MName'] . "'");
	exec("chmod +x /opt/minepeon/etc/cron.d/2min/GHFCcontractStatus");
	exec("chmod +x /opt/minepeon/etc/cron.d/5min/GHFCSubminerSTAT");
	
	
	header('Location: /plugins/ghfc/settings.php');
	die;
}


$refreshError =  $ghfc->checkIndexPhpRefresh();
if ($refreshError){
	exec("cp -rf /opt/minepeon/http/plugins/ghfc/head.php /opt/minepeon/http/head.php");
}


include('../../head.php');
include('../../menu.php');
$setting_ghfc_userEmail = '';
$setting_ghfc_appKey = '';
$setting_ghfc_paypalEmail = '';
$setting_ghfc_minerKey = '';
$setting_ghfc_machineName = '';


if (isset($settings['ghfc_userEmail'])){
	$setting_ghfc_userEmail = $settings['ghfc_userEmail'];
}

if (isset($settings['ghfc_appKey'])){
	$setting_ghfc_appKey = $settings['ghfc_appKey'];
}

if (isset($settings['ghfc_paypalEmail'])){
	$setting_ghfc_paypalEmail = $settings['ghfc_paypalEmail'];
}

if (isset($settings['ghfc_minerKey'])){
	$setting_ghfc_minerKey = $settings['ghfc_minerKey'];
}

if (isset($settings['ghfc_machineName'])){
	$setting_ghfc_machineName = $settings['ghfc_machineName'];
}


?>

<div class="container">
<?php if ($refreshError){?>

    We detected a faulty version of the head.php file and replaced it. This new file has no effect on the operation of your device.<br>
    Comments on the change are posted in the minepeon forums along with copy of the file.<br>
    <a href="http://minepeon.com/forums/download/file.php?id=269">head.php</a> posted on the minepeon forums page.<br>
        
<?php }?>
<form name="mma" action="/plugins/ghfc/settings.php" method="post" class="form-horizontal">
	 <A HREF="http://ghashforcash.com/Registration.html">* Register Now here *</a>
    <fieldset>
      <legend>GHashForCash Settings</legend>
      <div class="form-group">
        <label class="control-label col-lg-3">Email Adress</label>
        <div class="col-lg-9">
          <input type="email" placeholder="Email adress" name="Email" class="form-control" value="<?php echo $setting_ghfc_userEmail; ?>">
          <p class="help-block">
            Enter the email address registered with GHashForCash
          </p>
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-lg-3">PayPal Email Adress</label>
        <div class="col-lg-9">
          <input type="email" placeholder="PayPal Email adress" name="payPalEmail" class="form-control" value="<?php echo $setting_ghfc_paypalEmail; ?>">
          <p class="help-block">
            This is the email address of the PayPal account where you want us to send your payments
          </p>
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-lg-3">Miner Key</label>
        <div class="col-lg-9">
          <div class="input-group">
	<input type="text" placeholder="Miner Key" name="minerKey" class="form-control" value="<?php echo $setting_ghfc_minerKey; ?>">
          </div>
          <p class="help-block">
          	Enter the Miner Key received from GHashForCash (Each of your rigs should have a unique key)
          </p>
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-lg-3">Application Key</label>
        <div class="col-lg-9">
          <div class="input-group">
	<input type="text" placeholder="Application Key" name="AppKey" class="form-control" value="<?php echo $setting_ghfc_appKey; ?>">
          </div>
          <p class="help-block">
            Enter the Application Key received from GHashForCash  (Each of your rigs should have a unique key)
          </p>
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-lg-3">Machine Name</label>
        <div class="col-lg-9">
			<input type="text" placeholder="Machine Name" name="MName" class="form-control" value="<?php echo $setting_ghfc_machineName; ?>">
            <p class="help-block">
            [OPTIONAL] Enter what you would like to name this machine (no spaces!)
          </p>
        </div>
      </div>
      <div class="form-group">
        <div class="col-lg-9 col-offset-3">
          <button type="submit" class="btn btn-default">Save</button>
        </div>
      </div>
    </fieldset>

  </div>
  <!--Start of Zopim Live Chat Script-->
<script type="text/javascript">
window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
_.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute('charset','utf-8');
$.src='//v2.zopim.com/?1z4Iya87DEETfNNOJkeehxWgSkMCNTQV';z.t=+new Date;$.
type='text/javascript';e.parentNode.insertBefore($,e)})(document,'script');
</script>
<!--End of Zopim Live Chat Script-->
<?php

include('../../foot.php');
