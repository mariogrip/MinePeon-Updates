/usr/bin/php /opt/minepeon/http/plugins/ghfc/GHFCuninstall
sleep 3s
/usr/bin/php /opt/minepeon/http/plugins/ghfc/run.php uninstall
rm -rf /opt/minepeon/etc/cron.d/2min/GHFCcontractStatus
rm -rf /opt/minepeon/etc/cron.d/5min/GHFCSubminerSTAT