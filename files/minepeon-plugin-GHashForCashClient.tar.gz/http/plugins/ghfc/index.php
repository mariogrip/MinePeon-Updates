<?php
	$urlToRedirect = "settings.php";
	header('Location: '.$urlToRedirect);