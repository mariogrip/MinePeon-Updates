<?php
/* Cron Script
 * @package GHashForCash Addon for MinePeon
 * @author  James Thompson / 808mining
 * @version 0.6a
 * @date    2014-03-24
 */
require_once '/opt/minepeon/http/plugins/ghfc/ghashforcashclient.inc.php';


$ghfc  = new ghashForCashClient(true);

if(@$argv[1]){
  switch($argv[1]){
    case "installcron":
      //$ghfc->installCron();
      break;
  
    case "installconf":
       	
      $settings = array("email"=>$argv[2],"paypalemail"=>$argv[3],"minerkey"=>$argv[4], "appkey"=>$argv[5]);
      if(@$argv[6]){$settings["name"]=$argv[6];}
      
      
      $ghfc->installConf($settings);
      break;
     
    case "uninstall":
      $ghfc->uninstall();
    default:
      exit("No valid arguments were passed. Must be either update or check.");
  }
}else{
  exit("No valid arguments were passed. Must be either update or check.");
}
?>
